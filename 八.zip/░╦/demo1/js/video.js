	
   function playPause(){
    var myVideo=document.getElementById("myVideo");
      if (myVideo.paused) 
          myVideo.play();
      else  
         myVideo.pause();
    }
  function goBack(val) {
     myVideo.currentTime+=val;
    }
    function volume(val){
        myVideo.volume+=val;
       }
    
      function isMuted(){ 
       var isMuted=document.getElementById("isMuted"); 
          if (myVideo.muted) 
              myVideo.muted=false;
        
         else
             myVideo.muted=true;
        }